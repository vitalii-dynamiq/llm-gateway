"""Tests for fastlitellm."""
